//
//  EconViewController.swift
//  potato
//
//  Created by Merlin Zhao on 12/2/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit

class EconViewController: UIViewController,UITextFieldDelegate {
    
    //text fields
    @IBOutlet weak var q1text: UITextField!
    @IBOutlet weak var q2text: UITextField!
    @IBOutlet weak var q3text: UITextField!
    //button labels
    @IBOutlet weak var q1button: UIButton!
    @IBOutlet weak var q2button: UIButton!
    @IBOutlet weak var q3button: UIButton!
    
    //attempt labels
    @IBOutlet weak var attemptStringQ1: UILabel!
    @IBOutlet weak var attemptStringQ2: UILabel!
    @IBOutlet weak var attemptStringQ3: UILabel!
    
    //question fields
    @IBOutlet weak var q1: UILabel!
    @IBOutlet weak var q2: UILabel!
    @IBOutlet weak var q3: UILabel!
    
    //ALL DONE
    @IBOutlet weak var allDoneLabel: UIButton!
    
    
    
    //title
    @IBOutlet weak var chapterTitle: UILabel!
    
    //points earned
    var pointsEarned = 0
    
    //keep track of attempt
    var attemptsQ1 = 0
    var attemptsQ2 = 0
    var attemptsQ3 = 0
    
    
    //CREATE ALERT
    func createAlert(title: String, message: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "EXIT", style: UIAlertActionStyle.default, handler: {(action) in alert.dismiss(animated: true, completion: nil)
            
            self.dismiss(animated: true, completion: nil)
            
            self.pointsEarned = 0
            
        }))
        
        alert.addAction(UIAlertAction(title: "Stay", style: UIAlertActionStyle.cancel, handler: {(action) in alert.dismiss(animated: true, completion: nil)
            
        }))
        
        
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func cancel(_ sender: Any) {
        createAlert(title: "Don't leave!", message: "Leaving now will reset all answers and points earned. Are you sure you want to exit?")
    }
    
    @IBAction func allDone(_ sender: Any) {
        print(chapter1BO3)
        if chapter1BO3 == 1{
            chap1complete1BO3 = true
        }
        if chapter1BO3 == 2{
            chap2complete1BO3 = true
        }
        if chapter1BO3 == 3{
            chap3complete1BO3 = true
        }
        if chapter1BO3 == 4{
            chap4complete1BO3 = true
            
        }
        array.append("1BO3 Chapter "+String(chapter1BO3))
        
        date.append("+" + String(pointsEarned))
        
        weeklyPointsEarned += pointsEarned
        monthlyPointsEarned += pointsEarned
        totalPoints += pointsEarned
        weeklySetsCompleted += 1
        monthlySetsCompleted += 1
        
        
        
        createAlert(title: "You Have Submitted!", message: "You gained "+String(pointsEarned)+" SCENE points. You may EXIT now")

    }
    
    
    /*ANSWERS FOR QUESTIONS
    CHAPTER 1
    1. C   2. B   3. A
    CHAPTER 2
    1. B   2. B   3. A
     
    */
    //QUESTION ONE STUFFF
    //====================
    @IBAction func econq1action(_ sender: Any) {
        
        if chapter1BO3 == 1{
            if (q1text.text! == "C" || q1text.text! == "c"){
                q1button.setTitle("CORRECT",for: .normal)
                q1button.setTitleColor(UIColor.green, for: .normal)
                q1button.isEnabled = false
                pointsEarned += 5
            }
        }
        else if chapter1BO3 == 2{
            if (q1text.text! == "B" || q1text.text! == "b"){
                q1button.setTitle("CORRECT",for: .normal)
                q1button.setTitleColor(UIColor.green, for: .normal)
                q1button.isEnabled = false
                pointsEarned += 5
                
            }
        }
        else if chapter1BO3 == 3{
            if q1text.text! == "A" || q1text.text! == "a"{
                q1button.setTitle("CORRECT",for: .normal)
                q1button.setTitleColor(UIColor.green, for: .normal)
                q1button.isEnabled = false
                pointsEarned += 5
            }
        }
        else if chapter1BO3 == 4{
            if q1text.text! == "A" || q1text.text! == "a"{
                q1button.setTitle("CORRECT",for: .normal)
                q1button.setTitleColor(UIColor.green, for: .normal)
                q1button.isEnabled = false
                pointsEarned += 5
            }
        }
        //add and check attempts
        attemptsQ1 += 1
        attemptStringQ1.text = ( String(attemptsQ1) + "/3 attempts")
        if attemptsQ1 == 3{
            q1button.isEnabled = false
            q1button.setTitle("X",for: .normal)
            //change color
            q1button.setTitleColor(UIColor.red, for: .normal)
            
        }
        
        self.viewDidAppear(true)
        
    }
    
    //QUESTION TWO STUFFF
    //====================@@@@@@@@@@@
    @IBAction func econq2action(_ sender: Any) {
        if chapter1BO3 == 1{
            if q2text.text! == "B" || q2text.text! == "b"{
                q2button.setTitle("CORRECT",for: .normal)
                q2button.setTitleColor(UIColor.green, for: .normal)
                q2button.isEnabled = false
                pointsEarned += 5
            }
        }
        if chapter1BO3 == 2{
            if q2text.text! == "B" || q2text.text! == "b"{
                q2button.setTitle("CORRECT",for: .normal)
                q2button.setTitleColor(UIColor.green, for: .normal)
                q2button.isEnabled = false
                pointsEarned += 5
                
            }
            
            
        }
        if chapter1BO3 == 3{
            if q2text.text! == "C" || q2text.text! == "c"{
                q2button.setTitle("CORRECT",for: .normal)
                q2button.setTitleColor(UIColor.green, for: .normal)
                q2button.isEnabled = false
                pointsEarned += 5
            }
        }
        if chapter1BO3 == 4{
            if q2text.text! == "A" || q2text.text! == "a"{
                q2button.setTitle("CORRECT",for: .normal)
                q2button.setTitleColor(UIColor.green, for: .normal)
                q2button.isEnabled = false
                pointsEarned += 5
            }
        }
        //add and check attempts
        attemptsQ2 += 1
        attemptStringQ2.text = ( String(attemptsQ2) + "/3 attempts")
        if attemptsQ2 == 3{
            q2button.isEnabled = false
            q2button.setTitle("X",for: .normal)
            //change color
            q2button.setTitleColor(UIColor.red, for: .normal)
            
        }
        
        self.viewDidAppear(true)
        
    }
    
    
    //QUESTION THREE STUFF
    //++++++++++==========
    @IBAction func econq3action(_ sender: Any) {
        
        if chapter1BO3 == 1{
            if q3text.text! == "A"||q3text.text! == "a"{
                q3button.setTitle("CORRECT",for: .normal)
                q3button.setTitleColor(UIColor.green, for: .normal)
                q3button.isEnabled = false
                pointsEarned += 5
                
            }
        }
        if chapter1BO3 == 2{
            if q3text.text! == "A"||q3text.text! == "a"{
                q3button.setTitle("CORRECT",for: .normal)
                q3button.setTitleColor(UIColor.green, for: .normal)
                q3button.isEnabled = false
                pointsEarned += 5
                
            }
            
            
        }
        if chapter1BO3 == 3{
            if q3text.text! == "B"||q3text.text! == "b"{
                q3button.setTitle("CORRECT",for: .normal)
                q3button.setTitleColor(UIColor.green, for: .normal)
                q3button.isEnabled = false
                pointsEarned += 5
            }
        }
        
        if chapter1BO3 == 4{
            if q3text.text! == "B"||q3text.text! == "b"{
                q3button.setTitle("CORRECT",for: .normal)
                q3button.setTitleColor(UIColor.green, for: .normal)
                q3button.isEnabled = false
                pointsEarned += 5
            }
        }
        //add and check attempts
        attemptsQ3 += 1
        attemptStringQ3.text = ( String(attemptsQ3) + "/3 attempts")
        if attemptsQ3 == 3{
            q3button.isEnabled = false
            q3button.setTitle("X",for: .normal)
            //change color
            q3button.setTitleColor(UIColor.red, for: .normal)
            
        }
        
        self.viewDidAppear(true)
        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        chapterTitle.text = chapter1BO3name
        if chapter1BO3 == 1{
            q1.text = "1. What is microeconomics about? \n A) Study of business environment\n B) Study of financial position of the economy\n C) Study of Economy at Micro Level\n D) None of the above"
            q2.text = "2. Law of Demand states that\n A) With the increase in price quantity increases\n B) With the increase in price quantity decreases other things remaining the same\n C) Quantity does not change with any increase in price\n D) All of the above"
            q3.text = "3. The Slope of Indifference Curve indicates\n A) Marginal Rate of Substitution of x for y\n B) Prices of x and y\n C) Slope of the budget line\n D) Change in prices"
        }
        if chapter1BO3 == 2{
            q1.text = "1. Production Function Shows\n A) Prices of input and output\n B) Relationship between output and input\n C) Various combinations of inputs\n D) All of the above"
            q2.text = "2. Shape of Total Fixed Cost(TFC) curve is\n A) Verticle\n B) Horizontal\n C) 45 degree line\n D) None of the above"
            q3.text = "3. While in perfect competition\n A) Firms are price taker\n B) Buyers are independant\n C) Input prices are given\n D) None of the above"
        }
        if chapter1BO3 == 3{
            q1.text = "1. Model of Monopolistic Competition is characterized by\n A) Homogenous goods\n B) Differentiated goods\n C) Substitute goods\n D) All of the above"
            q2.text = "2. Monopoly is a form of market where there is\n A) Large number of buyers\n B) Small number of buyers\n C) A single firm controlling the market\n D) Any of the above"
            q3.text = "3. In Duopoly, there is/are\n A) Many firms\n B) Two firms controlling the market\n C) Large corporations\n D) None of the above"
        }
        if chapter1BO3 == 4{
            q1.text = "1. Price discrimination is a situation when a producer\n A) Charges different prices in different market\n B) Charges same price\n C) Charges many prices\n D) All of the above"
            q2.text = "2. Total revenue equals the quantity of output the firm produces times the price at which it sells its output\n A) True\n B) False"
            q3.text = "3. Wages and salaries paid to workers are an example of implicit costs of production\n A) True\n B) False"
        }
        else if chapter1BO3 == 2{
            
            
            
        }
        else if chapter1BO3 == 3 {
            
        }
        else if chapter1BO3 == 4 {
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        q1text.delegate = self
        q2text.delegate = self
        q3text.delegate = self
        
        allDoneLabel.layer.cornerRadius = 8
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
