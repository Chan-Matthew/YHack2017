//
//  One1XX1ViewController.swift
//  potato
//
//  Created by Merlin Zhao on 12/2/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit
var chapter1XX1 = 0
var chapter1XX1name = ""
var chap0complete1XX1 = false
var chap1complete1XX1 = false
var chap2complete1XX1 = false
var chap3complete1XX1 = false
class One1XX1ViewController: UIViewController {
    //button as labels
    @IBOutlet weak var C0: UIButton!
    @IBOutlet weak var C1: UIButton!
    @IBOutlet weak var C2: UIButton!
    @IBOutlet weak var C3: UIButton!
    
    
    
    //button actions
    @IBAction func C0(_ sender: Any) {
        chapter1XX1 = 0
        chapter1XX1name = "Chapter 0: How rewards work"
        performSegue(withIdentifier: "to1XX1Quiz", sender: self)
    }
    @IBAction func C1(_ sender: Any) {
        chapter1XX1 = 1
        chapter1XX1name = "Chapter 1: Numbers"
        performSegue(withIdentifier: "to1XX1Quiz", sender: self)
    }
    @IBAction func C2(_ sender: Any) {
        chapter1XX1 = 2
        chapter1XX1name = "Chapter 2: Arithmatics"
        performSegue(withIdentifier: "to1XX1Quiz", sender: self)
    }
    @IBAction func C3(_ sender: Any) {
        chapter1XX1 = 3
        chapter1XX1name = "Chapter 3: Words and Multiple Choice"
        performSegue(withIdentifier: "to1XX1Quiz", sender: self)
    }
    
    
    
    @IBAction func back(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    override func viewDidAppear(_ animated: Bool) {
        if chap0complete1XX1 == true{
            C0.setTitle("Chapter 0: COMPLETED",for: .normal)
            C0.isEnabled = false
        }
        if chap1complete1XX1 == true{
            C1.setTitle("Chapter 1: COMPLETED",for: .normal)
            C1.isEnabled = false
        }
        if chap2complete1XX1 == true{
            C2.setTitle("CORRECT 2: COMPLETED",for: .normal)
            C2.isEnabled = false
        }
        if chap3complete1XX1 == true{
            C3.setTitle("CORRECT 3: COMPLETED",for: .normal)
            C3.isEnabled = false
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        C0.layer.cornerRadius = 12
        C1.layer.cornerRadius = 12
        C2.layer.cornerRadius = 12
        C3.layer.cornerRadius = 12

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
