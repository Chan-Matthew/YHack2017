//
//  FirstViewController.swift
//  potato
//
//  Created by Merlin Zhao on 12/1/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit
import Foundation
import HealthKit
var count = 0
var totalPoints = 0
class FirstViewController: UIViewController {
    
    
    
    //HEALTH-------------

    
    private func authorizeHealthKit() {
        let healthStore = HKHealthStore()
        
        let objectTypes: Set<HKObjectType> = [
            HKObjectType.activitySummaryType()
        ]
        
        healthStore.requestAuthorization(toShare: nil, read: objectTypes) { (success, error) in
            
            // Authorization request finished, hopefully the user allowed access!
        }
        
    }
    

    
    
    
    
    
    
    //main points symbol
    @IBOutlet weak var points: UILabel!
    
    
    //VIEWS
    @IBOutlet weak var viewOne: UIView!
    @IBOutlet weak var viewTwo: UIView!
    @IBOutlet weak var viewThree: UIView!
    //buttons
    @IBOutlet weak var offerOneButton: UIButton!
    @IBOutlet weak var offerTwoButton: UIButton!
    @IBOutlet weak var offerThreeButton: UIButton!
    //image views
    @IBOutlet weak var offerImageOne: UIImageView!
    @IBOutlet weak var offerImageTwo: UIImageView!
    @IBOutlet weak var offerImageThree: UIImageView!
    
    
    @IBAction func workoutStart(_ sender: Any) {
        authorizeHealthKit()
    }
    
    
    
    
    //button for course ealuation
    @IBAction func offerOne(_ sender: Any) {
        
        if let url = URL(string: "https://evals.mcmaster.ca/") {
            UIApplication.shared.open(url, options: [:])
        
        }
        totalPoints += 50
        array.append("Survey offer")
        date.append("+"+String(totalPoints))
    }
    
    //button for macleans card
    @IBAction func offerTwo(_ sender: Any) {
        if let url = URL(string: "http://www.macleans.ca/tag/canadian-university-survey-consortium/") {
            UIApplication.shared.open(url, options: [:])
        
        }
        totalPoints += 100
        array.append("Survey offer")
        date.append("+"+String(totalPoints))
    }
    
    override func viewDidAppear(_ animated: Bool) {
        points.text = String(totalPoints)
        
        let zeroIcon = UIApplicationShortcutIcon(type: UIApplicationShortcutIconType.home)
        let zeroItem = UIApplicationShortcutItem(type: "ssssss", localizedTitle: "Dashboard: " + String(totalPoints) + "Pts", localizedSubtitle: nil, icon: zeroIcon , userInfo: nil)
        let firstIcon = UIApplicationShortcutIcon(type: UIApplicationShortcutIconType.bookmark)
        let firstItem = UIApplicationShortcutItem(type: "ssssss", localizedTitle: "Learn", localizedSubtitle: nil, icon: firstIcon , userInfo: nil)
        let secondIcon = UIApplicationShortcutIcon(type: UIApplicationShortcutIconType.time)
        let secondItem = UIApplicationShortcutItem(type: "ssssss", localizedTitle: "History", localizedSubtitle: nil, icon: secondIcon , userInfo: nil)
        UIApplication.shared.shortcutItems = [zeroItem, firstItem,secondItem]
    
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        viewOne.layer.cornerRadius = 8
        viewTwo.layer.cornerRadius = 8
        viewThree.layer.cornerRadius = 12
        offerOneButton.layer.cornerRadius = 8
        offerTwoButton.layer.cornerRadius = 8
        offerThreeButton.layer.cornerRadius = 8
        offerImageOne.layer.cornerRadius = 8
        offerImageTwo.layer.cornerRadius = 8
        offerImageThree.layer.cornerRadius = 8
        
        
        
        

        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

