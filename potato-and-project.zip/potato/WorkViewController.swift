//
//  WorkViewController.swift
//  potato
//
//  Created by Merlin Zhao on 12/3/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit
import Foundation
import HealthKit
import HealthKitUI

var eTemp = 0.0
var startCal = 0.0
var endCal = 0.0


class WorkViewController: UIViewController {
    
    @IBOutlet weak var pointsEarned: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var finalPoints: UILabel!
    @IBOutlet weak var SCENE: UIImageView!
    
    //HEALTH KIT _---------------
    func activityData() {
        
        let healthStore = HKHealthStore()
        let calendar = Calendar.autoupdatingCurrent
        
        var dateComponents = calendar.dateComponents(
            [ .year, .month, .day ],
            from: Date()
        )
        
        
        // This line is required to make the whole thing work
        dateComponents.calendar = calendar
        
        
        
        let predicate = HKQuery.predicateForActivitySummary(with: dateComponents)
        
        
        let query = HKActivitySummaryQuery(predicate: predicate) { (query, summaries, error) in
            
            guard let summaries = summaries, summaries.count > 0
                else {
                    // No data returned. Perhaps check for error
                    return
            }

            var energyUnit  = HKUnit.jouleUnit(with: .kilo)
            var energyTemp = summaries[0].activeEnergyBurned.doubleValue(for: HKUnit.kilocalorie())
            eTemp = energyTemp
            print(eTemp )
            
            
            
        }
        healthStore.execute(query)
        
    }
    
    //BACK BUTTON
    @IBOutlet weak var back: UIButton!
    @IBAction func backButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    

    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var endButton: UIButton!
    @IBAction func button(_ sender: Any) {
        back.isHidden = true
        activityData()
        sleep(1)
        startCal = eTemp
   
        startButton.isHidden = true
        endButton.isHidden = false
        
        print(startCal)

        
        
    }
    
    @IBAction func endWorkout(_ sender: Any) {
        activityData()
        sleep(1)
        endCal = eTemp
    
        
        totalLabel.isHidden = false
        totalLabel.text = String(Int(endCal - startCal))+"CAL"
        back.isHidden = false
        SCENE.isHidden = false
        pointsEarned.isHidden = false
        
        var calPoints = Int(endCal - startCal)*3
        finalPoints.text = String(calPoints)
        finalPoints.isHidden = false
        
        totalPoints += calPoints
        
        //add to history
        array.append("Bonus activity")
        date.append("+"+String(calPoints))
        
        print(endCal)
    }
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
