//
//  EconMenuViewController.swift
//  potato
//
//  Created by Merlin Zhao on 12/2/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit
var chapter1BO3 = 0
var chapter1BO3name = ""

var chap1complete1BO3 = false
var chap2complete1BO3 = false
var chap3complete1BO3 = false
var chap4complete1BO3 = false

class EconMenuViewController: UIViewController {
    //button as labels
    @IBOutlet weak var chapOneLabel: UIButton!
    @IBOutlet weak var chapTwoLabel: UIButton!
    @IBOutlet weak var chapThreeLabel: UIButton!
    @IBOutlet weak var chapFourLabel: UIButton!
    
    
    
    //back button
    @IBAction func back(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    //chapter 1 button
    @IBAction func chapOneButton(_ sender: Any) {
        performSegue(withIdentifier: "to1BO3quiz", sender: self)
        chapter1BO3 = 1
        chapter1BO3name = "Chapter 1: Basics of Microeconomics"
    }
    
    //chapter 2 button
    @IBAction func chapTwoButton(_ sender: Any) {
        performSegue(withIdentifier: "to1BO3quiz", sender: self)
        chapter1BO3 = 2
        chapter1BO3name = "Chapter 2: Lectures 1-3"
    }
    
    
    @IBAction func chapThreeButton(_ sender: Any) {
        performSegue(withIdentifier: "to1BO3quiz", sender: self)
        chapter1BO3 = 3
        chapter1BO3name = "Chapter 3: Lectures 4-5"
    }
    
    
    @IBAction func chapFourButton(_ sender: Any) {
        performSegue(withIdentifier: "to1BO3quiz", sender: self)
        chapter1BO3 = 4
        
        chapter1BO3name = "Chapter 4: Lectures 6-11"
    }
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        if chap1complete1BO3 == true{
            chapOneLabel.setTitle("Chapter 1: COMPLETED",for: .normal)
            chapOneLabel.isEnabled = false
        }
        if chap2complete1BO3 == true{
            chapTwoLabel.setTitle("Chapter 2: COMPLETED",for: .normal)
            chapTwoLabel.isEnabled = false
        }
        if chap3complete1BO3 == true{
            chapThreeLabel.setTitle("Chapter 3: COMPLETED",for: .normal)
            chapThreeLabel.isEnabled = false
        }
        if chap4complete1BO3 == true{
            chapFourLabel.setTitle("Chapter 4: COMPLETED",for: .normal)
            chapFourLabel.isEnabled = false
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        chapOneLabel.layer.cornerRadius = 12
        chapTwoLabel.layer.cornerRadius = 12
        chapThreeLabel.layer.cornerRadius = 12
        chapFourLabel.layer.cornerRadius = 12
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
