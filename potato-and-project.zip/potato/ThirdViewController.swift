//
//  ThirdViewController.swift
//  potato
//
//  Created by Merlin Zhao on 12/1/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit
var array = ["Completed"]
var date = ["Points"]
class ThirdViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    @IBOutlet weak var myTableView: UITableView!
    
    override func viewDidAppear(_ animated: Bool) {
        myTableView.reloadData()
    }

    override func viewDidLoad() {
      
        super.viewDidLoad()
        
        myTableView.delegate = self
        myTableView.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = array[indexPath.row]
        cell?.detailTextLabel?.text = "\(date[indexPath.row])"
        return cell!
    }
    
    
}


