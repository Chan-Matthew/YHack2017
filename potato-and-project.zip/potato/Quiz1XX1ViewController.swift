//
//  Quiz1XX1ViewController.swift
//  potato
//
//  Created by Merlin Zhao on 12/2/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit

class Quiz1XX1ViewController: UIViewController,UITextFieldDelegate {
    //index 0 = chapter 0. index 1 = chapter 1.... and so on
    /*let question: [[String]] = [["REWARDS"],[["1. Enter in the number 10.","2. Enter in the number 3.1415 Round to four decimal points.","3. Enter in 0."],["10","3.1415","0"]],["1. What is 1 + 1?","2. What is 5/2? Round to one decimal place.", "3. Enter 1.5 as a fraction."],["2","2.5","3/2"],["How do you spell 'blue'?","Enter in 'a' to choose option a on a multiple choice question. Enter in 'a'","Name of a person should be capitalized. Enter in 'Evan'."],["blue","a","Evan"]]*/
    
    //Declare all labels
    @IBOutlet weak var quizTitle: UILabel!
    @IBOutlet weak var q1: UILabel!
    @IBOutlet weak var q2: UILabel!
    @IBOutlet weak var q3: UILabel!
    
    //sumbitbutons
    @IBOutlet weak var q1button: UIButton!
    @IBOutlet weak var q2button: UIButton!
    @IBOutlet weak var q3button: UIButton!
    //textfields
    @IBOutlet weak var q1text: UITextField!
    @IBOutlet weak var q2text: UITextField!
    @IBOutlet weak var q3text: UITextField!
    //attempt labels
    @IBOutlet weak var q1attempt: UILabel!
    @IBOutlet weak var q2attempt: UILabel!
    @IBOutlet weak var q3attempt: UILabel!
    

    var attemptsQ1 = 0
    var attemptsQ2 = 0
    var attemptsQ3 = 0
    //set strings to be called viewdidappear
    var attemptStringQ1 = "0/3 attempts"
    var attemptStringQ2 = "0/3 attempts"
    var attemptStringQ3 = "0/3 attempts"
    
    //keep track of points
    var pointsEarned = 0
    
    //CREATE ALERT
    func createAlert(title: String, message: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "EXIT", style: UIAlertActionStyle.default, handler: {(action) in alert.dismiss(animated: true, completion: nil)
            
            self.dismiss(animated: true, completion: nil)
            
            self.pointsEarned = 0
            
        }))
        
        alert.addAction(UIAlertAction(title: "Stay", style: UIAlertActionStyle.cancel, handler: {(action) in alert.dismiss(animated: true, completion: nil)
            
        }))
        
        
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    
    @IBAction func q1action(_ sender: Any) {

        if chapter1XX1 == 1{
            if q1text.text! == "10"{
                q1button.setTitle("CORRECT",for: .normal)
                q1button.setTitleColor(UIColor.green, for: .normal)
                q1button.isEnabled = false
                pointsEarned += 5
                
            }
        }
        if chapter1XX1 == 2{
            if q1text.text! == "2"{
                q1button.setTitle("CORRECT",for: .normal)
                q1button.setTitleColor(UIColor.green, for: .normal)
                q1button.isEnabled = false
                pointsEarned += 5
    
            }
        }
        if chapter1XX1 == 3{
            if q1text.text! == "blue"{
                q1button.setTitle("CORRECT",for: .normal)
                q1button.setTitleColor(UIColor.green, for: .normal)
                q1button.isEnabled = false
                pointsEarned += 5
            }
        }
        
        //add and check attempts
        //Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!Q!
        attemptsQ1 += 1
        attemptStringQ1 = ( String(attemptsQ1) + "/3 attempts")
        if attemptsQ1 == 3{
            q1button.isEnabled = false
            q1button.setTitle("X",for: .normal)
            //change color
            q1button.setTitleColor(UIColor.red, for: .normal)
            
        }
    
        self.viewDidAppear(true)
    }
    
    @IBAction func q2action(_ sender: Any) {
        
        //for chapter 0
        if chapter1XX1 == 0{
            if q2text.text! == "yes"{
                q2button.setTitle("CORRECT",for: .normal)
                q2button.setTitleColor(UIColor.green, for: .normal)
                q2button.isEnabled = false
                pointsEarned += 100
            }
        }
        
        if chapter1XX1 == 1{
            
            if q2text.text! == "3.1415"{
                q2button.setTitle("CORRECT",for: .normal)
                q2button.setTitleColor(UIColor.green, for: .normal)
                q2button.isEnabled = false
                pointsEarned += 5
            }
            
        }
        if chapter1XX1 == 2{
            if q2text.text! == "2.5"{
                q2button.setTitle("CORRECT",for: .normal)
                q2button.setTitleColor(UIColor.green, for: .normal)
                q2button.isEnabled = false
                pointsEarned += 5
            }
        }
        if chapter1XX1 == 3{
            if q2text.text! == "a"{
                q2button.setTitle("CORRECT",for: .normal)
                q2button.setTitleColor(UIColor.green, for: .normal)
                q2button.isEnabled = false
                pointsEarned += 5
                
            }
        }
        //add and check attempts
        //Q@Q@Q@Q@Q@Q@Q@Q@Q@Q@Q@Q@Q@Q@
        attemptsQ2 += 1
        attemptStringQ2 = ( String(attemptsQ2) + "/3 attempts")
        if attemptsQ2 == 3{
            q2button.isEnabled = false
            q2button.setTitle("X",for: .normal)
            //change color
            q2button.setTitleColor(UIColor.red, for: .normal)
            
        }
        
        self.viewDidAppear(true)
    }
    
    @IBAction func q3action(_ sender: Any) {
        
        if chapter1XX1 == 1{
            if q3text.text! == "0"{
                q3button.setTitle("CORRECT",for: .normal)
                q3button.setTitleColor(UIColor.green, for: .normal)
                q3button.isEnabled = false
                pointsEarned += 5
            
            }
        }
        if chapter1XX1 == 2{
            if q3text.text! == "((3/2*2)+7)"{
                q3button.setTitle("CORRECT",for: .normal)
                q3button.setTitleColor(UIColor.green, for: .normal)
                q3button.isEnabled = false
                pointsEarned += 5
                
            }

            
        }
        if chapter1XX1 == 3{
            if q3text.text! == "Evan"{
                q3button.setTitle("CORRECT",for: .normal)
                q3button.setTitleColor(UIColor.green, for: .normal)
                q3button.isEnabled = false
                pointsEarned += 5
            }
        }
        //add and check attempts
        //Q#Q#Q#Q#Q#Q#Q#Q#QQ#Q#Q#Q#Q#Q#Q#Q#Q#Q#Q#
        attemptsQ3 += 1
        attemptStringQ3 = ( String(attemptsQ1) + "/3 attempts")
        if attemptsQ3 == 3{
            q3button.isEnabled = false
            q3button.setTitle("X",for: .normal)
            //change color
            q3button.setTitleColor(UIColor.red, for: .normal)
            
        }
        
        self.viewDidAppear(true)
        
    }
    
    //ALL DONEEEE
    @IBOutlet weak var done: UIButton!
    @IBAction func allDone(_ sender: Any) {
        weeklyPointsEarned += pointsEarned
        monthlyPointsEarned += pointsEarned
        totalPoints += pointsEarned
        weeklySetsCompleted += 1
        monthlySetsCompleted += 1
        
        if chapter1XX1 == 0{
            chap0complete1XX1 = true
        }
        else if chapter1XX1 == 1{
            chap1complete1XX1 = true
        }
        else if chapter1XX1 == 2{
            chap2complete1XX1 = true
        }
        else if chapter1XX1 == 3{
            chap3complete1XX1 = true
        }
       
        array.append("1XX1 Chapter "+String(chapter1XX1))
       
        date.append("+" + String(pointsEarned))
        createAlert(title: "You Have Submitted!", message: "You gained "+String(pointsEarned)+" SCENE points. You may EXIT now")
        
       
        
    }
    
    
    
    
    //cencel button
    @IBAction func cancel(_ sender: Any) {
        createAlert(title: "Don't leave!", message: "Leaving now will reset all answers and points earned. Are you sure you want to exit?")
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        quizTitle.text = chapter1XX1name
        if chapter1XX1 == 0{
            q1text.isHidden = true
            q3text.isHidden = true
            q1button.isHidden = true
            q3button.isHidden = true
            q3.isHidden = true
            
            q1attempt.isHidden = true
            q3attempt.isHidden = true
            
            
            q1.text = "Potato is very simple to use. You get rewarded by completeing question sets. For each question you get correct, you will get a certain amount of points."
            q2.text = "There are many special offers on your dashboard, so look out for those!\nIf you understand Potato rewards, type 'yes' in the textfield below."
        }
        
        
        if chapter1XX1 == 1{
            q1.text = "1. Enter in the number 10."
            q2.text = "2. Enter in the number 3.1415 Round to four decimal points."
            q3.text = "3. Enter in 0."
            q1text.keyboardType = UIKeyboardType.decimalPad
            q2text.keyboardType = UIKeyboardType.decimalPad
            q3text.keyboardType = UIKeyboardType.decimalPad
            
        }
        if chapter1XX1 == 2{
            q1.text = "1. What is 1 + 1? Questions with numbers should     have no spaces in front or after the number."
            q2.text = "2. What is 5/2? Round to one decimal place. Questions requiring decimals will state rounding expectations"
            q3.text = "3. Enter 1.5 * 2 + 7 as an equation. No spaces should be between numbers and symbols. ((3/2*2)+7 )"
            
        }
        if chapter1XX1 == 3{
            q1.text = "1. How do you spell 'blue'? No spaces should be before or after a single word answer"
            q2.text = "2. Enter in 'a' to choose option a on a multiple choice question. Enter in 'a'"
            q3.text = "3. The name of a person should be capitalized. Enter in 'Evan'."
            
        }
        
        //set attempts label
        q1attempt.text = attemptStringQ1
        q2attempt.text = attemptStringQ2
        q3attempt.text = attemptStringQ3
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        q1text.delegate = self
        q2text.delegate = self
        q3text.delegate = self
        done.layer.cornerRadius = 8

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
