//
//  SecondViewController.swift
//  potato
//
//  Created by Merlin Zhao on 12/1/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit

var weeklyPointsEarned = 0
var weeklySetsCompleted = 0

var monthlyPointsEarned = 0
var monthlySetsCompleted = 0


class SecondViewController: UIViewController , UIViewControllerPreviewingDelegate{
    
    
    //all buttons as label
    @IBOutlet weak var to1XX1button: UIButton!
    @IBOutlet weak var toCourseFourbutton: UIButton!
    @IBOutlet weak var toCourseThreebutton: UIButton!
    @IBOutlet weak var toCourseTwobutton: UIButton!
    @IBOutlet weak var toCourseOnebutton: UIButton!
    
    //progess labels
    //weekly
    @IBOutlet weak var weeklyPoints: UILabel!
    @IBOutlet weak var weeklySets: UILabel!
    //monthly
    @IBOutlet weak var monthlyPoints: UILabel!
    @IBOutlet weak var monthlySets: UILabel!
    
    
    
    
    //to1XX1
    @IBAction func to1XX1(_ sender: Any) {
        performSegue(withIdentifier: "to1XX1", sender: self)
    }
    //to1BO3
    @IBAction func to1BO3(_ sender: Any) {
        performSegue(withIdentifier: "to1BO3", sender: self)
    }
    
    
    
    
    
    
    //HEALTH STUFF
    //+++++++++++++++
 
    
    
    //+++++++++++++++++
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        weeklyPoints.text = "Points earned: "+String(weeklyPointsEarned)
        weeklySets.text = "Problem sets completed: " + String(weeklySetsCompleted)
        monthlySets.text = "Problem sets completed: " + String(monthlySetsCompleted)
        monthlyPoints.text = "Points earned: " + String(monthlyPointsEarned)
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        to1XX1button.layer.cornerRadius = 12
        toCourseOnebutton.layer.cornerRadius = 12
        toCourseTwobutton.layer.cornerRadius = 12
        toCourseThreebutton.layer.cornerRadius = 12
        toCourseFourbutton.layer.cornerRadius = 12
        // Do any additional setup after loading the view, typically from a nib.
        
        //CHECKING FOR 3D TOUCH SUPPORT
        if traitCollection.forceTouchCapability == UIForceTouchCapability.available{
            registerForPreviewing(with: self, sourceView: view)
        }
       
    }
    
    func previewingContext(_ previewingContext: UIViewControllerPreviewing, viewControllerForLocation location: CGPoint) -> UIViewController? {
        let previewView = storyboard?.instantiateViewController(withIdentifier: "1XX1")
        return previewView
    }
    
    func previewingContext(_ previewingContext: UIViewControllerPreviewing, commit viewControllerToCommit: UIViewController) {
        let finalView = storyboard?.instantiateViewController(withIdentifier: "1XX1")
        show(finalView!, sender: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

